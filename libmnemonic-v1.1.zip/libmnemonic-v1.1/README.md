# libmnemonic

Key stretching library for C++

## Usage

```C++
// Create a mnemonic
uint8_t *randomData = ...; // Bytes from a secure random data source
string mnemonic = encodeToMnemonic(randomData);

// The mnemonic string can be presented to the user as a backup method

// Generating the private key seed from the mnemonic string
bytes derivedSeed = mnemonicToSeed(mnemonic);
```

Check the mnemonic.h file for additional information like the exceptions
used for the error handling.

## Development

To run the tests execute

$ make
$ ./mnemonic-tests
