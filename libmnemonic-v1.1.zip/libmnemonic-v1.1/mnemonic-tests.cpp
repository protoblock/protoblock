#include <iostream>
#include <algorithm>
#include <cassert>
#include "mnemonic.h"

using namespace std;

void runTest(string mnemonic, bytes entropy, bytes seed);
// Internal functions defined in mnemonic.cpp
string encodeToMnemonic(bytes& data);
bytes decodeMnemonic(const string& mnemonic);

int main(void) {

    runTest("judge emply jealous roughing lift carry pearl motion noise disease slant bar",
            bytes({ 0x68, 0x85, 0xcd, 0x99, 0xd7, 0x97, 0x38, 0x20, 0xe5, 0x24, 0x38, 0x8d, 0x44, 0x67, 0x05, 0x83 }),
            bytes({ 0xfb, 0x40, 0x75, 0xb9, 0x44, 0x49, 0x2b, 0x7a, 0x37, 0x41, 0xa4, 0x5d, 0x09, 0x30, 0x0e, 0xd7, 0xc0, 0x33, 0x5d, 0x72, 0x78, 0x31, 0xdb, 0x61, 0xb0, 0x40, 0x31, 0x97, 0xef, 0x62, 0xb3, 0x05 }));

    runTest("bomb stock stock oval stunt smooth second comeback hike pass warm hole reject faith job fire moon sharpe",
            bytes({ 0x0b, 0xb9, 0xb7, 0x36, 0xc8, 0xbd, 0x01, 0x87, 0x6d, 0xe8, 0xaf, 0x56, 0xf2, 0x67, 0xd6, 0xac, 0x3a, 0x64, 0x70, 0x19, 0xc9, 0xec, 0x86, 0x17 }),
            bytes({ 0x7c, 0x50, 0x70, 0x3d, 0x5f, 0x43, 0x93, 0xff, 0xc3, 0xcf, 0xbe, 0x5a, 0x10, 0x6b, 0xe1, 0xb7, 0x86, 0xb9, 0x0d, 0xaa, 0xee, 0x70, 0x91, 0x77, 0xad, 0x48, 0xc5, 0xa2, 0xf4, 0x6b, 0x65, 0x57 }));

    try {
        decodeMnemonic("roughing lift carry pearl motion noise");
        cout << "Error expected exception" << endl;
        assert(false);
    }
    catch (MnemonicChecksumException& e) {}
    catch (MnemonicException& e) {
        cout << "Error " << e.what() << endl;
        assert(false);
    }

    try {
        decodeMnemonic("invalidWord judge emply jealous roughing lift carry pearl motion noise disease slant");
        cout << "Error expected exception" << endl;
        assert(false);
    }
    catch (MnemonicWordException& e) {}
    catch (MnemonicException& e) {
        cout << "Error " << e.what() << endl;
        assert(false);
    }

    try {
        decodeMnemonic("smooth");
        cout << "Error expected exception" << endl;
        assert(false);
    }
    catch (MnemonicLengthException& e) {}
    catch (MnemonicException& e) {
        cout << "Error " << e.what() << endl;
        assert(false);
    }

    cout << "Tests pass OK" << endl;
    return EXIT_SUCCESS;
}

void runTest(string mnemonic, bytes entropy, bytes seed) {

    bytes decodedEntropy = decodeMnemonic(mnemonic);
    assert(entropy == decodedEntropy);

    string newMnemonic = encodeToMnemonic(entropy);
    assert(newMnemonic == mnemonic);

    bytes derivedSeed = mnemonicToSeed(mnemonic);
    assert(derivedSeed == seed);

    newMnemonic = createMnemonic(entropy.data(), entropy.size());
    assert(newMnemonic == mnemonic);
}






